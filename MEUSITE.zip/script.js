emailjs.init("XbOOtp1V4QdOOQnM9");

const form = document.getElementById("contact-form");
const statusMsg = document.getElementById("status-msg");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  statusMsg.textContent = "Enviando...";

  emailjs.sendForm("service_6cmzkfg", "template_r682dfn", this)
    .then(() => {
      statusMsg.textContent = "Mensagem enviada com sucesso!";
      form.reset();
    }, (error) => {
      statusMsg.textContent = "Erro ao enviar. Tente novamente.";
      console.error("Erro:", error);
    });
});

function toggleMenu() {
  const nav = document.getElementById("nav-links");
  nav.classList.toggle("show");
}
